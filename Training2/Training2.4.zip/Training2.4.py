# Get two float numbers from user input
num1 = float(input("Enter first decimal number: "))
num2 = float(input("Enter second decimal number: "))

# Add the numbers and convert to integer
result = int(num1 + num2)

# Display the result
print(f"The integer result is: {result}")