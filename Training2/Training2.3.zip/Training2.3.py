
# Exercici 3: llegir tres paraules i imprimir una frase amb totes tres

w1 = input("Introdueix la primera paraula: ").strip()
w2 = input("Introdueix la segona paraula: ").strip()
w3 = input("Introdueix la tercera paraula: ").strip()

frase = f"{w1} {w2} {w3}."
print("Frase formada:", frase)
