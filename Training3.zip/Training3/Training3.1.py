# Programa que demana l'edat de l'usuari i indica si és menor o adult
edat = int(input("Introdueix la teva edat: "))
if edat < 18:
    print("Ets menor d'edat.")
else:
    print("Ets adult.")