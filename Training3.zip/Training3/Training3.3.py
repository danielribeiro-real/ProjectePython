num1 = int(input("Introdueix un nombre: "))
if num1 >= 0:
    print("El nombre és positiu.")
else:
    print("El nombre és negatiu.")
# Programa que demana un nombre i indica si és positiu, negatiu o zero